package simple.demo1

import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class Name(val fname: String, val lname: String)

fun main() {
    val json = Json.encodeToString(Name("Vaishali", "Tapaswi"))
    println(json)
    val json1 = """{"fname":"Fands", "lname":"Infonet"}"""

    val data = Json.decodeFromString<Name>(json1)
    println(data)
}

