package simple.demo1

fun main() {
    val  s:String ="Vaishali"
    println(s)
    s.aaa("cc")
    val  list = mutableListOf<String>("a","b","c","d")
    println(list)
    list.reverse11()
    println(list)

}

private fun <E> MutableList<E>.reverse11() {

    println("in reverse")
    this.reverse()
}

private fun String.aaa(s: String) {
    println("in aaa " + s)


}
