package simple.demo1

data class Address(var line1: String, var line2:String?, var city:String,var state:String)
data class Person(var name:String, var addr:Address?)
fun main() {
    var name:String?  = "aa"
    var nm:String="aaa"
    println(name)
    println(name?.length)

    println(nm?.length)

    name = null

    println(nm?.length)

    println(name)
    var len:Int = name?.length?:0
    println(len)

    var addr1 = Address("aaa","Kapply","hyd","ap")
    println(addr1.line1 + "," + (addr1.line2?:"")  +", " + addr1.city +", " + addr1.state)

    addr1 = Address("bbb",null,"hyd1","ap1")
    println(addr1.line1 + "," + (addr1.line2?:"")  +", " + addr1.city +", " + addr1.state)


}