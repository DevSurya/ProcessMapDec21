package com.example.demo4

import kotlinx.serialization.Serializable

@Serializable
data class Dept(val deptno: Int, val dname:String, val loc: String)

