package simple.demo1

fun main() {
 val sqrlambda :(Int) -> Int={s ->s*s}
 val cubelambda :(Int) -> Int={s ->s*s*s}
 val horder:(no1:Int,myfn:(Int)->Int)->Int={no1,myfn->myfn(no1)}
 println(sqrlambda(50))
 println("SQR " + horder(10,sqrlambda))
 println("Cube" + horder(10,cubelambda))
 }

