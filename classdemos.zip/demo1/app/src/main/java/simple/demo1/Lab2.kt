package simple.demo1


data class Dept(var deptno:Int, var dname:String,var loc:String)

fun main() {

var list= mutableListOf<Dept>()
list.add(Dept(10,"HR","Hyd"))
    list.add(Dept(20,"HR","Pnq"))
    list.add(Dept(30,"it","Blr"))
    list.add(Dept(40,"fIN","Hyd"))
    println(list)
    list.replaceAll({d->
        d.dname ="HR"
        return@replaceAll d
    })
    println("After Replace ...")
    println(list)
    list.removeAll { d ->
        d.loc == "Hyd"
    }
    println("After RemoveALl")
    println(list)

}
// list.removeAll({d->d.loc=="Hyd"}