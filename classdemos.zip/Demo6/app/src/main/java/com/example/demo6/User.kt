package com.example.demo6


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity()
data class User(
    @PrimaryKey
    @ColumnInfo(name = "namecol") val name: String,
    @ColumnInfo(name = "agecol") val age: Int?
)
/*
  "userId": 1,
  "id": 1,
  "title": "delectus aut autem",
  "completed": false

 */