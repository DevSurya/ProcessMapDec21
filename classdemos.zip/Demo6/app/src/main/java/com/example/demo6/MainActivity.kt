package com.example.demo6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "database-name"
        ).allowMainThreadQueries().fallbackToDestructiveMigration().build()

        val user = User( "v2",22)
        /// Connect -> https://reqres.in/api/users?page=2
   ///     download data and insert records in db
        db.userDao().insertAll(user)
        val users: List<User> = db.userDao().getAll()

        users.forEach{
            println(it)
        }

    }
}