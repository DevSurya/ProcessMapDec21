package com.example.uistates

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {
            f_name_et.setText("Welcome to HelloAndroid!");
        } else {
            f_name_et.setText("Welcome back.");
        }

    }

    public override fun onSaveInstanceState(savedInstanceState: Bundle) {
        super.onSaveInstanceState(savedInstanceState)
        println(".............onSaveInstanceState")

        savedInstanceState.putString("f_name", f_name_et.text.toString())
        savedInstanceState.putBoolean("cb_value", checkBox.isChecked)
    }
/*
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        println(".....................onRestoreInstanceState")

        val fn = savedInstanceState.getString("f_name")

        val cb = savedInstanceState.getBoolean("cb_value")

        //set value to UI
        f_name_et.setText(fn)
        //l_name_et.setText(ln)
        checkBox.isChecked = cb

    }

 */
}
