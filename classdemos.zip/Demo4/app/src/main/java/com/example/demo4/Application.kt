package com.example.demo4

import io.ktor.application.*
import io.ktor.features.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*
import io.ktor.serialization.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*

val deptstorage = mutableListOf<Dept>()
fun main() {
    embeddedServer(Netty, port = 3000, module = Application::module).start(wait = true)
}

fun Application.module() {
        println("...................Application.module")

        install(ContentNegotiation) {
            json()
        }

        routing {
            get("/dept") {
                if (deptstorage.isNotEmpty()) {
                    call.respond(deptstorage)
                } else {
                    call.respondText("No departments found", status = HttpStatusCode.NotFound)
                    val dept = Dept(10, "HR", "Hyd")
                    deptstorage.add(dept)
                }
            }
            get("/dept/{id}") {
                val id = call.parameters["id"] ?: return@get call.respondText(
                    "Missing or malformed id",
                    status = HttpStatusCode.BadRequest
                )
                val dept =
                    deptstorage.find { it.deptno == id.toInt() } ?: return@get call.respondText(
                        "No department with deptno $id",
                        status = HttpStatusCode.NotFound
                    )
                call.respond(dept)
            }
            post("/dept") {
                println(call.request)
                val dept = call.receive<Dept>()
                deptstorage.add(dept)
                call.respondText("Customer stored correctly", status = HttpStatusCode.Created)
            }


        }
    }

