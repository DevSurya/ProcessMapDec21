package simple.demo2


class User1(val map: MutableMap<String, Any?>) {
    var name: String by map
    var age: Int     by map
}
fun main() {
    var user = User1(mapOf(
        "name" to "John Doe",
        "age"  to 25
    ).toMutableMap())
    println(user.name) // Prints "John Doe"
    user.name = "aaa"
    println(user.name) // Prints "John Doe"
    println(user.age)  // Prints 25

}