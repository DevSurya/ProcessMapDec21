package simple.demo2

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main(){
    println("in main")
    var j1 = GlobalScope.launch {
        var c =  add(10,20)
        println("Output from add method "+ c)
    }
    println("in main after job1")
   runBlocking{
        j1.join()
    }

}


suspend fun add(a:Int,b:Int):Int{
    var d = (0..2000).random()
    delay(d.toLong())
    return a + b
}