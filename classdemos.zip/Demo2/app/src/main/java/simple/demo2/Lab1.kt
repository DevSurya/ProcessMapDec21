package simple.demo2

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun main() {
    println("Hello ")

    GlobalScope.launch {
        println("Just before Delay1")
        delay(1000L)
        println("after delay1")
    }
    GlobalScope.launch {
        println("Just before Delay2")
        delay(1000L)
        println("after delay2")
    }
    readLine()
    println("World !!!")

}