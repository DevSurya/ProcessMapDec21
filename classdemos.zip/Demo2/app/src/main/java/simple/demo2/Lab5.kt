package simple.demo2

val CheckLazyValue: String by lazy {
    println("Computed for CheckLazyValue!")
    "Hello"
}
val CheckValue: String
    get() {
        println("Computed for check value!")
        return  "Hello"
    }

fun main() {
    println(CheckValue)
    println(CheckValue)
    println(CheckLazyValue)
    println(CheckLazyValue)
}
