package com.example.app10mvvm

data class Blog(
    var title:String
)
