package com.example.demo3

class Maths {
    fun sqr(no : Int):Int {
        return no*no;
    }
}

fun main() {
    val c = Maths::class
   // val maths = Maths()
    println("List of Constructors ...")
    c.constructors.forEach{ println(it)}
    val maths = c.constructors.stream().findFirst().get().call();

    println("List of Members ...")
    c.members.forEach{ println(it)}
    println("SQR Function")
    val fnsqr =  c.members.filter { it.name=="sqr" }.first()
    println(fnsqr)
    println(fnsqr.call(maths, 100))
}