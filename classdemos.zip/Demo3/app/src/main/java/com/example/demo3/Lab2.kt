package com.example.demo3

import com.example.mylib.MyClass

fun main() {
    val myclass = MyClass()
    println("SQR of 10 is " + myclass.sqr(10))
    println("Cube of 10 is " + myclass.cube(10))
}