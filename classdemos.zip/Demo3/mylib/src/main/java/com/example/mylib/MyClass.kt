package com.example.mylib

class MyClass {

    fun sqr(no : Int):Int {
        println("mylib-MyClass-SQR invoked ")
        return no*no;
    }

    fun cube(no : Int):Int {
        println("mylib-MyClass-SQR invoked ")
        return no*no*no;
    }
}