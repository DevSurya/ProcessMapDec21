package com.example.demo5

data class Todo(var userId: Int, var id:Int, var title: String, var completed:Boolean)