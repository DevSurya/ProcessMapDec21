package com.example.demo5

import android.app.Application
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    var btn: Button? = null
    var view1: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn = findViewById<Button>(R.id.button)
        view1 = findViewById<TextView>(R.id.txtview)
        val apiInterface = ApiInterface.create().getTodo()
        btn?.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                println("in onclick listener....")
                apiInterface.enqueue(object : Callback<Todo> {
                    override fun onResponse(call: Call<Todo>?, response: Response<Todo>?) {
                        println("in onResponse listener")

                        var str: String = response?.body()?.toString() ?: "notfound"
                        view1?.setText(str)
                        Toast.makeText(this@MainActivity, str, Toast.LENGTH_SHORT).show()
                        //recyclerAdapter.setMovieListItems(response.body()!!)
                    }

                    override fun onFailure(call: Call<Todo>?, t: Throwable?) {
                        println("on failuer" + call?.request())
                        println("on Failure" + t?.message)
                        view1?.text = "Failure ...."
                    }
                })
            }
        })
    }
}

